#!/system/bin/sh
ui_print ""
ui_print "  InvisibleX Loader"
ui_print ""

MODID=invisiblex_loader
OLD=/data/adb/modules/$MODID

# Preserve the user's settings across updates
if [ -f "$OLD/config/config.json" ]; then
  ui_print "- Keeping existing config"
  mkdir -p "$MODPATH/config"
  cp -f "$OLD/config/config.json" "$MODPATH/config/config.json"
fi

# Preserve an already-installed binary, whatever it is named
if [ -d "$OLD/bin" ]; then
  for F in "$OLD"/bin/*; do
    [ -f "$F" ] || continue
    case "${F##*/}" in loader.sh|kpm.sh|binpath.sh|*.h|*.md|*.txt|*.log) continue;; esac
    cp -f "$F" "$MODPATH/bin/" 2>/dev/null && ui_print "- Kept binary: ${F##*/}"
  done
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh"           0 0 0755
set_perm "$MODPATH/daemon/ff_watcher.sh" 0 0 0755
set_perm "$MODPATH/bin/loader.sh"        0 0 0755
set_perm "$MODPATH/bin/kpm.sh"           0 0 0755
set_perm "$MODPATH/webroot/api.sh"       0 0 0755
set_perm "$MODPATH/webroot/net.sh"       0 0 0755
set_perm "$MODPATH/bin/binpath.sh"       0 0 0755
set_perm "$MODPATH/bin/hwid.sh"          0 0 0755
for F in "$MODPATH"/bin/*; do
  case "${F##*/}" in *.h|*.md|*.txt) continue;; esac
  [ -f "$F" ] && set_perm "$F" 0 0 0755
done

if [ -n "$(sh "$MODPATH/bin/binpath.sh" 2>/dev/null)" ]; then
  ui_print "- Binary: present"
else
  ui_print "! No binary yet. Copy your build to:"
  ui_print "!   $MODPATH/bin/inx.sh"
  ui_print "!   then reboot (or press Start in WebUI)"
fi

ui_print ""
ui_print "- Reboot, then open the module WebUI"
ui_print ""

ui_print "- chmod bin"
for b in $MODPATH/bin/*; do
  [ -f "$b" ] && chmod 755 "$b" 2>/dev/null
done

ui_print "- fix bin permissions (777)"
mkdir -p $MODPATH/bin $MODPATH/certs
for b in $MODPATH/bin/*; do
  [ -f "$b" ] && chmod 777 "$b" 2>/dev/null
done
# ensure auth helper is executable even if zip lost +x
[ -f "$MODPATH/bin/ix_webui_auth" ] && chmod 777 "$MODPATH/bin/ix_webui_auth"
[ -f "$MODPATH/bin/hwid.sh" ] && chmod 777 "$MODPATH/bin/hwid.sh"
[ -f "$MODPATH/bin/loader.sh" ] && chmod 777 "$MODPATH/bin/loader.sh"
[ -f "$MODPATH/bin/api.sh" ] || true

