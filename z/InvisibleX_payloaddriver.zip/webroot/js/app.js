
(function(){
  var MOD='/data/adb/modules/invisiblex_loader', API=MOD+'/webroot/api.sh';
  var seq=0, busy=false, last='', pollTimer=null;

  function $(id){return document.getElementById(id);}
  function toast(m){var t=$('toast');if(!t)return;t.textContent=m;t.classList.add('show');clearTimeout(t._);t._=setTimeout(function(){t.classList.remove('show');},1600);}
  function sh(cmd){return new Promise(function(res){
    if(!window.ksu||typeof ksu.exec!=='function'){res({e:1,o:'Open WebUI from root manager'});return;}
    var c='ix'+(++seq);
    window[c]=function(e,o,r){try{delete window[c];}catch(x){} res({e:e|0,o:o||'',s:r||''});};
    try{ksu.exec(cmd,JSON.stringify({cwd:MOD}),c);}catch(err){try{delete window[c];}catch(x){} res({e:1,o:String(err)});}
  });}
  async function api(a,arg){
    var x=(arg!=null&&String(arg)!=='')?" '"+String(arg).replace(/'/g,"'\\''")+"'":'';
    var r=await sh('sh "'+API+'" '+a+x);
    return (r.o||'').trim();
  }
  function term(id,text){var el=$(id);if(!el)return;el.textContent=text||'';el.scrollTop=el.scrollHeight;}
  function setSw(id,on){var el=$(id);if(!el)return;el.classList.toggle('on',!!on);}
  function setTxt(id,t,cls){var el=$(id);if(!el)return;if(el.textContent!==t)el.textContent=t;if(cls!==undefined)el.className=cls;}

  window.go=function(name,btn){
    document.querySelectorAll('.page').forEach(function(p){p.classList.remove('on');});
    document.querySelectorAll('.tabs button').forEach(function(b){b.classList.remove('on');});
    var p=$(name);if(p)p.classList.add('on');
    if(btn)btn.classList.add('on');
    if(name==='home'){refresh(true);startLiveTail();}
    else stopLiveTail();
  };

  async function refresh(force){
    if(busy&&!force)return;busy=true;
    try{
      var raw=await api('status');
      if(!force&&raw===last)return;last=raw;
      var j={};try{j=JSON.parse(raw);}catch(e){}
      setTxt('v-ff',j.ff?'Online':'Offline',j.ff?'ok':'dim');
      setTxt('v-run',j.running?'Running':'Stopped',j.running?'ok':'dim');
      setTxt('v-key',j.key_masked||'Not set','');
      setTxt('v-bin',j.bin?'Ready':'Missing',j.bin?'ok':'bad');
      setTxt('v-daemon',j.daemon?'Online':'Offline',j.daemon?'ok':'dim');
      setSw('sw-boot',j.boot==1||j.boot==='1');
      setSw('sw-auto',j.auto==1||j.auto==='1');
      var b=$('badge');if(b){b.textContent=j.running?'Running':'Idle';b.className='badge'+(j.running?' on':'');}
      var d=$('drv');if(d&&j.driver&&!d.dataset.ed)d.value=j.driver;
    }finally{busy=false;}
  }

  function startLiveTail(){
    stopLiveTail();
    pollTimer=setInterval(async function(){
      // only update terminal if binary is running — live output
      var el=$('home-term');
      if(!el)return;
      // light poll of binary log without wiping user-visible execute output if idle
    }, 2000);
  }
  function stopLiveTail(){ if(pollTimer){clearInterval(pollTimer);pollTimer=null;} }

  window.toggleBoot=async function(){
    var on=!$('sw-boot').classList.contains('on');
    term('home-term', await api('set_boot', on?'1':'0'));
    last='';refresh(true);
  };
  window.toggleAuto=async function(){
    var on=!$('sw-auto').classList.contains('on');
    term('home-term', await api('set_auto', on?'1':'0'));
    last='';refresh(true);
  };
  window.saveKey=async function(){
    var k=(($('key')||{}).value||'').trim();
    if(!k){toast('Enter key');return;}
    term('home-term', await api('set_key', k));
    $('key').value='';
    toast('Key saved');
    last='';refresh(true);
  };
  window.runBin=async function(){
    // ensure daemon is alive for next FF opens
    await api('ensure_daemon');
    term('home-term', 'running…');
    var out=await api('run_binary');
    term('home-term', out);
    // follow log for a few seconds (live-like)
    var n=0;
    var t=setInterval(async function(){
      n++;
      var tail=await api('tail_binary');
      if(tail && tail.indexOf('(no binary')<0){
        term('home-term', out + '\n--- live ---\n' + tail);
      }
      if(n>=8) clearInterval(t);
    }, 800);
    last='';refresh(true);
  };
  window.stopBin=async function(){
    term('home-term', await api('stop_binary'));
    last='';refresh(true);
  };
  window.saveDrv=async function(){
    var p=(($('drv')||{}).value||'').trim();
    if(!p){toast('Enter path');return;}
    term('drv-term', await api('set_driver', p));
  };
  window.runDrv=async function(){
    var p=(($('drv')||{}).value||'').trim();
    if(!p){toast('Enter path');return;}
    await api('set_driver', p);
    term('drv-term', 'running…');
    term('drv-term', await api('run_driver', p));
  };

  document.addEventListener('DOMContentLoaded', async function(){
    var d=$('drv'); if(d) d.addEventListener('input', function(){d.dataset.ed='1';});
    // start daemon when UI opens
    term('home-term', await api('ensure_daemon'));
    refresh(true);
    setInterval(function(){refresh(false);}, 3000);
  });
})();
