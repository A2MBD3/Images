#!/system/bin/sh
# InvisibleX strong watcher — must stay alive 24/7
MODDIR="${MODDIR:-/data/adb/modules/invisiblex_loader}"
[ -f "$0" ] && MODDIR=$(cd "$(dirname "$0")" && pwd)

LOG=/data/local/tmp/inx_logs/daemon.log
BIN="$MODDIR/bin/inx.sh"
PIDF=/data/local/tmp/inx_loader.pid
FLAG=/data/local/tmp/inx_running.flag
LOCK=/data/local/tmp/inx_daemon.lock
KEYF="$MODDIR/config/key.txt"
AUTOF="$MODDIR/config/auto_ff.txt"
PACKAGES="com.dts.freefiremax com.dts.freefireth"

mkdir -p /data/local/tmp/inx_logs

# single instance
if [ -f "$LOCK" ]; then
  OLD=$(cat "$LOCK" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ]; then
    # already running
    exit 0
  fi
fi
echo $$ > "$LOCK"

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }
log "daemon pid=$$ path=$MODDIR"

ff_running() {
  # method 1: pidof
  for p in $PACKAGES; do
    if pidof "$p" >/dev/null 2>&1; then return 0; fi
  done
  # method 2: scan /proc cmdline (works when pidof is limited)
  for c in /proc/[0-9]*/cmdline; do
    [ -r "$c" ] || continue
    # cmdline is NUL-separated
    if tr '\0' ' ' < "$c" 2>/dev/null | grep -qE 'com\.dts\.freefire(max|th)'; then
      return 0
    fi
  done
  # method 3: toybox/ps
  if ps -A 2>/dev/null | grep -qE 'com\.dts\.freefire(max|th)'; then
    return 0
  fi
  return 1
}

bin_alive() {
  [ -f "$PIDF" ] || return 1
  BP=$(cat "$PIDF" 2>/dev/null)
  [ -n "$BP" ] && [ -d "/proc/$BP" ] && return 0
  return 1
}

prep_key() {
  K=$(tr -d '\r\n' < "$KEYF" 2>/dev/null)
  export INX_LICENSE_KEY="$K"
  export KD_LICENSE_KEY="$K"
  printf '%s' "$K" > /data/local/tmp/.inx_license_key
  printf '%s' "$K" > /data/local/tmp/.kd_saved_key
  chmod 600 /data/local/tmp/.inx_license_key /data/local/tmp/.kd_saved_key 2>/dev/null
  echo "$K"
}

start_bin() {
  [ -f "$BIN" ] || { log "ERROR binary missing $BIN"; return 1; }
  chmod 755 "$BIN" 2>/dev/null
  if bin_alive; then
    log "binary already up"
    return 0
  fi
  K=$(prep_key)
  log "START binary key_len=${#K}"
  # clean old flag
  rm -f "$FLAG"
  (
    cd "$MODDIR" || exit 1
    # log binary stdout/stderr to dedicated file for UI
    if [ -n "$K" ]; then
      printf '%s\n' "$K" | "$BIN" >> /data/local/tmp/inx_logs/binary.log 2>&1 &
    else
      "$BIN" >> /data/local/tmp/inx_logs/binary.log 2>&1 &
    fi
    echo $! > "$PIDF"
    touch "$FLAG"
  )
  sleep 0.15
  if bin_alive; then
    log "OK started pid=$(cat "$PIDF")"
  else
    log "WARN binary exited immediately — see binary.log"
  fi
}

stop_bin() {
  if [ -f "$PIDF" ]; then
    BP=$(cat "$PIDF" 2>/dev/null)
    if [ -n "$BP" ]; then
      kill "$BP" 2>/dev/null
      sleep 0.15
      kill -9 "$BP" 2>/dev/null
    fi
  fi
  # kill by path match
  for c in /proc/[0-9]*/cmdline; do
    [ -r "$c" ] || continue
    if tr '\0' ' ' < "$c" 2>/dev/null | grep -q "invisiblex_loader/bin/inx"; then
      kill "$(echo "$c" | cut -d/ -f3)" 2>/dev/null
    fi
  done
  rm -f "$PIDF" "$FLAG"
  log "STOP binary"
}

WAS=0
# main loop — fast detect (~1s)
while true; do
  # re-read auto flag each loop
  AUTO=$(cat "$AUTOF" 2>/dev/null || echo 1)
  if [ "$AUTO" = "1" ] && ff_running; then
    if [ "$WAS" -eq 0 ]; then
      log "FF OPEN detected"
      start_bin
      WAS=1
    else
      # still in game — restart binary if it died
      if ! bin_alive; then
        log "binary died in-game — restart"
        start_bin
      fi
    fi
  else
    if [ "$WAS" -eq 1 ]; then
      log "FF CLOSE detected"
      stop_bin
      WAS=0
    fi
  fi
  sleep 1
done
