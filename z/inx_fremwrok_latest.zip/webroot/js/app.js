const MOD='/data/adb/modules/invisiblex_loader';
const API=MOD+'/webroot/api.sh';
/* Auth URL lives in compiled bin/ix_webui_auth — not here */
const ENDPOINT=''; /* unused for login */

let hwid='', lastAuth=null, busy=false, kinfo=null, drvFilter='match', drvCache=[];

/* ── shell bridge ── */
let seq=0;
function sh(cmd){
  return new Promise(res=>{
    if(!window.ksu||typeof ksu.exec!=='function'){res({errno:1,stdout:'',stderr:'nobridge'});return;}
    const cb='ixcb'+(++seq);
    window[cb]=(e,o,r)=>{delete window[cb];res({errno:e,stdout:o||'',stderr:r||''});};
    try{ksu.exec(cmd,JSON.stringify({cwd:MOD}),cb);}catch(x){delete window[cb];res({errno:1,stdout:'',stderr:String(x)});}
  });
}
const ready=()=>!!(window.ksu&&typeof ksu.exec==='function');
const jparse=s=>{try{return JSON.parse(String(s).trim());}catch(e){return null;}};

function toast(m,k){const t=document.getElementById('toast');t.textContent=m;
  t.className='toast show '+(k||'');clearTimeout(t._h);t._h=setTimeout(()=>t.className='toast',2300);}

/* network from the WebView — this ROM has no curl */
async function httpJSON(url){
  try{
    const c=new AbortController(), t=setTimeout(()=>c.abort(),12000);
    const r=await fetch(url,{cache:'no-store',signal:c.signal});
    clearTimeout(t);
    if(!r.ok) return {__err:'HTTP '+r.status};
    return jparse(await r.text())||{__err:'bad reply'};
  }catch(e){return {__err:String(e.message||e)};}
}

/* ── tabs ── */
function showTab(n,btn){
  document.querySelectorAll('.pane').forEach(p=>p.classList.add('hidden'));
  document.querySelectorAll('.tb').forEach(b=>b.classList.remove('on'));
  document.getElementById('tab-'+n).classList.remove('hidden');
  btn.classList.add('on'); window.scrollTo(0,0);
  if(n==='login')    initLogin();
  if(n==='settings') initSettings();
  if(n==='drv')      initDrv();
  if(n==='home')     refresh();
}

/* ══════ HOME ══════ */
const DNAME={kma:'KMA KPM',ldk:'LDK KPM',tb:'TB KPM',ditpro:'DitPro KPM',
             qx1:'QX1',qx2:'QX 2',gt:'GT',rtdev:'rt-dev',rtproc:'rt-proc'};

async function refresh(){
  if(!ready())return;
  const r=await sh(
    'P=$(cat '+MOD+'/config/watcher.pid 2>/dev/null); '+
    'if [ -n "$P" ] && kill -0 "$P" 2>/dev/null; then echo "RUN|$P"; else echo "STOP|"; fi; '+
    'grep -o \'"driver"[^,}]*\' '+MOD+'/config/config.json 2>/dev/null|cut -d: -f2|tr -d \' "\'; '+
    'grep -o \'"hwid_status"[^,}]*\' '+MOD+'/config/config.json 2>/dev/null|cut -d: -f2|tr -d \' "\'; '+
    '[ -n "$(sh '+MOD+'/bin/binpath.sh)" ] && echo BIN_OK || echo BIN_NO; '+
    'uname -r'
  );
  const L=r.stdout.split('\n');
  const run=(L[0]||'').indexOf('RUN')===0;
  const drv=(L[1]||'').trim()||'kma';
  const st =(L[2]||'').trim()||'unknown';
  const bin=(L[3]||'').indexOf('BIN_OK')!==-1;
  const ker=(L[4]||'').trim();

  document.getElementById('heroRing').classList.toggle('live',run);
  document.getElementById('heroIcon').textContent=run?'◉':'○';
  document.getElementById('heroLabel').textContent=run?'Watching for game':'Service stopped';
  document.getElementById('ctaTxt').textContent=run?'Stop Service':'Start Service';
  document.getElementById('ctaBtn').classList.toggle('stop',run);
  document.getElementById('hdrPill').classList.toggle('on',run);
  document.getElementById('hdrState').textContent=run?'Active':'Idle';

  document.getElementById('sDriver').textContent=DNAME[drv]||drv.toUpperCase();
  document.getElementById('sKernel').textContent=ker?ker.split('-')[0]:'—';
  const ok=(st==='active');
  const a=document.getElementById('sAuth');
  a.textContent=ok?'Valid':(st==='unknown'?'Not checked':st);
  a.style.color=ok?'var(--grn)':(st==='unknown'?'':'var(--red)');
  document.getElementById('sDays').textContent=
    (lastAuth&&lastAuth.days_remaining!=null)?lastAuth.days_remaining+' days':'—';
  document.getElementById('binCard').hidden=bin;

  mk('st1',!!hwid); mk('st2',ok); mk('st3',true); mk('st4',run);
}
function mk(id,d){const e=document.getElementById(id);if(e)e.classList.toggle('done',!!d);}

async function toggleService(){
  if(busy||!ready())return; busy=true;
  const b=document.getElementById('ctaBtn'); b.disabled=true;
  const r=await sh('cat '+MOD+'/config/watcher.pid 2>/dev/null');
  const pid=r.stdout.trim();
  const c=pid?await sh('kill -0 '+pid+' 2>/dev/null && echo y'):{stdout:''};
  if(c.stdout.trim()==='y'){
    await sh('kill '+pid+' 2>/dev/null; rm -f '+MOD+'/config/watcher.pid');
    toast('Service stopped');
  }else{
    await sh('nohup sh '+MOD+'/daemon/ff_watcher.sh >/dev/null 2>&1 & echo $! > '+MOD+'/config/watcher.pid');
    toast('Service started','ok');
  }
  setTimeout(()=>{b.disabled=false;busy=false;refresh();},900);
}

/* ══════ LICENSE ══════ */
async function initLogin(){
  if(!ready())return;
  if(!hwid){const r=await sh('sh '+API+' hwid');hwid=r.stdout.trim();}
  document.getElementById('hwidTxt').textContent=hwid||'Unable to read';
  if(!lastAuth)checkAuth();
}
function copyHWID(){
  if(!hwid)return;
  const d=()=>toast('Hardware ID copied','ok');
  if(navigator.clipboard)navigator.clipboard.writeText(hwid).then(d).catch(d);
  else{const t=document.createElement('textarea');t.value=hwid;document.body.appendChild(t);
       t.select();try{document.execCommand('copy');}catch(e){}t.remove();d();}
}
function openTelegram(){window.open('https://t.me/registerhardware_bot','_blank');}

/* Login/status via COMPILED binary — no keys/URL crypto in JS */
const AUTHBIN=MOD+'/bin/ix_webui_auth';
async function binJSON(args){
  const r=await sh(AUTHBIN+' '+args);
  const line=(r.stdout||'').trim().split('\n').filter(Boolean).pop()||'';
  const j=jparse(line);
  if(j) return j;
  if(r.errno) return {__err:(r.stderr||'auth binary failed').slice(0,120)};
  return {__err:'bad reply from auth binary'};
}

async function checkAuth(){
  if(!ready())return;
  const box=document.getElementById('statusBox');box.className='statusbox';
  document.getElementById('sIcon').textContent='…';
  document.getElementById('sTitle').textContent='Checking';
  document.getElementById('sSub').textContent='Contacting server';
  if(!hwid){const h=await sh('sh '+API+' hwid');hwid=h.stdout.trim();}
  /* ensure binary exists */
  const chk=await sh('[ -x '+AUTHBIN+' ] && echo OK || echo NO');
  if((chk.stdout||'').indexOf('OK')<0){
    box.className='statusbox bad';
    document.getElementById('sIcon').textContent='!';
    document.getElementById('sTitle').textContent='Auth binary missing';
    document.getElementById('sSub').textContent='Place ix_webui_auth in bin/ and chmod 755';
    return;
  }
  const d=await binJSON("status '"+String(hwid).replace(/'/g,'')+"'");
  if(d.__err){
    box.className='statusbox bad';
    document.getElementById('sIcon').textContent='!';
    document.getElementById('sTitle').textContent='Cannot reach server';
    document.getElementById('sSub').textContent=d.__err;
    return;
  }
  lastAuth=d;
  if(d.status)sh('sh '+API+' save_status '+d.status);
  const M2={active:['ok','✓','Active','Device registered and ready'],
    not_registered:['warn','○','Not registered','Send your Hardware ID to the bot'],
    not_activated:['warn','○','Not activated','Key not activated yet'],
    expired:['bad','✕','Expired','Renew with your seller'],
    banned:['bad','✕','Banned','Stopped by admin'],
    disabled:['bad','✕','Disabled','Seller account disabled']};
  const m=M2[(d.status||'').toLowerCase()]||['warn','?','Unknown',d.error||''];
  box.className='statusbox '+m[0];
  document.getElementById('sIcon').textContent=m[1];
  document.getElementById('sTitle').textContent=m[2];
  document.getElementById('sSub').textContent=m[3];
  document.getElementById('kKey').textContent=d.key_masked||'—';
  document.getElementById('kCheat').textContent=d.cheat||'—';
  document.getElementById('kSeller').textContent=d.seller||'—';
  document.getElementById('kExp').textContent=d.expires_at?
    d.expires_at+(d.days_remaining!=null?'  ('+d.days_remaining+'d)':''):'—';
  if(d.devices_used!=null){
    document.getElementById('kDev').textContent=d.devices_used+' / '+(d.max_devices||'?');
    document.getElementById('devBarWrap').hidden=false;
    document.getElementById('devBar').style.width=
      Math.min(100,(d.devices_used/Math.max(1,d.max_devices))*100)+'%';
  }
  refresh();
}

/* ══════ DRIVERS ══════ */
const MODES=[['qx1',1,'QX1'],['gt',2,'GT'],['rtdev',3,'rt-dev'],['rtproc',4,'rt-proc'],
             ['qx2',5,'QX (2)'],['tb',6,'TB KPM'],['ditpro',7,'DitPro KPM'],
             ['kma',8,'KMA KPM'],['ldk',9,'LDK KPM']];







/* upload — chunked base64 through the shell bridge */

/* ══════ SETTINGS ══════ */

/* ── DRIVER: path / load / load-on-boot / mode ── */
const DMODE={kma:['KMA KPM',8],ldk:['LDK KPM',9],tb:['TB KPM',6],
  ditpro:['DitPro KPM',7],qx1:['QX1',1],qx2:['QX 2',5],gt:['GT',2],
  rtdev:['rt-dev',3],rtproc:['rt-proc',4]};

async function saveDriver(){
  const s=document.querySelector('input[name="driver"]:checked'); if(!s) return;
  const r=await sh('sh '+API+' set_driver '+s.value);
  const ok=r.stdout.indexOf('OK')!==-1;
  const m=DMODE[s.value];
  toast(ok?(m?m[0]:s.value)+' selected':'Save failed', ok?'ok':'err');
  const tag=document.getElementById('modeTag');
  if(tag&&m) tag.textContent='mode '+m[1];
  refresh();
}


async function initDrv(){
  if(!ready()) return;
  const r = await sh('sh '+API+' get_kpm');
  const d = jparse(r.stdout) || {};

  document.getElementById('kpmPath').value   = d.path || '';
  document.getElementById('kpmBoot').checked = (String(d.boot) === 'true');

  const mgr = (d.manager || 'none');
  const tag = document.getElementById('mgrTag');
  if(mgr === 'none' || mgr.indexOf('none') === 0){
    tag.textContent = 'no loader';
    tag.style.color = 'var(--acc)';
  }else{
    tag.textContent = mgr.split(':')[0];
    tag.style.color = '';
  }
}

async function saveKpmPath(){
  const v = document.getElementById('kpmPath').value.trim();
  await sh('sh '+API+' set_kpm_path '+JSON.stringify(v));
  return v;
}

async function kpmLoad(){
  if(!ready()) return;
  const btn = document.getElementById('loadBtn');
  const out = document.getElementById('kpmOut');

  const path = await saveKpmPath();
  if(!path){ toast('Enter a path first','err'); return; }

  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = 'Loading…';
  out.hidden = false;
  out.textContent = 'Executing ' + path + ' …';

  const r = await sh('sh '+API+' kpm_load '+JSON.stringify(path));
  const t = (r.stdout || r.stderr || '').trim();
  out.textContent = t || '(no output)';

  const ok = t.indexOf('OK') === 0;
  toast(ok ? 'Driver loaded' : 'Load failed', ok ? 'ok' : 'err');

  btn.disabled = false;
  btn.textContent = old;
}

async function saveKpmBoot(){
  const on = document.getElementById('kpmBoot').checked;
  await saveKpmPath();
  await sh('sh '+API+' set_kpm_boot '+(on ? 'true' : 'false'));
  toast(on ? 'Will load on boot' : 'Boot loading off');
}


/* ── TERMINAL ── */
let termHist=[], termIdx=-1;

function termPrint(txt,cls){
  const o=document.getElementById('termOut');
  if(o.textContent==='Ready.') o.textContent='';
  o.innerHTML += (cls?'<span class="'+cls+'">':'') +
    String(txt).replace(/&/g,'&amp;').replace(/</g,'&lt;') +
    (cls?'</span>':'') + '\n';
  o.scrollTop = o.scrollHeight;
}
function termClear(){ document.getElementById('termOut').textContent='Ready.'; }

function termKey(e){
  if(e.key==='Enter'){ termRun(); return; }
  // up/down walk the history
  if(e.key==='ArrowUp'   && termIdx<termHist.length-1){
    termIdx++; e.target.value=termHist[termHist.length-1-termIdx]; }
  if(e.key==='ArrowDown'){
    if(termIdx>0){ termIdx--; e.target.value=termHist[termHist.length-1-termIdx]; }
    else { termIdx=-1; e.target.value=''; }
  }
}

function termQuick(c){
  // short aliases so the buttons stay readable
  const A={ 'kpm list':'sh '+MOD+'/bin/kpm.sh list',
            'ls -l bin':'ls -l '+MOD+'/bin',
            'log':'tail -30 '+MOD+'/config/loader.log' };
  document.getElementById('termIn').value = A[c] || c;
  termRun();
}

async function termRun(){
  if(!ready()) return;
  const inp=document.getElementById('termIn');
  const cmd=inp.value.trim();
  if(!cmd) return;

  termHist.push(cmd); termIdx=-1; inp.value='';
  termPrint('$ '+cmd,'tcmd');

  const r=await sh(cmd);
  const out=(r.stdout||'').replace(/\s+$/,'');
  const err=(r.stderr||'').replace(/\s+$/,'');
  if(out) termPrint(out);
  if(err) termPrint(err,'terr');
  if(!out && !err) termPrint('(no output, exit '+(r.errno||0)+')','tdim');
}

async function initSettings(){
  if(!ready())return;
  const r=await sh('cat '+MOD+'/config/config.json 2>/dev/null');
  const c=jparse(r.stdout)||{};
  document.getElementById('enabledToggle').checked=(c.enabled!==false);

  // driver mode lives here now — restore the saved selection
  const cur=c.driver||'kma';
  document.querySelectorAll('input[name="driver"]').forEach(x=>x.checked=(x.value===cur));
  const mtag=document.getElementById('modeTag');
  if(mtag&&DMODE[cur]) mtag.textContent='mode '+DMODE[cur][1];

  // Menu open: vol | bar
  const mo=(c.menu_open==='bar')?'bar':'vol';
  document.querySelectorAll('input[name="menu_open"]').forEach(x=>x.checked=(x.value===mo));
  const mentag=document.getElementById('menuTag');
  if(mentag) mentag.textContent=(mo==='bar')?'Bar':'Volume';
}

async function saveMenuOpen(){
  const s=document.querySelector('input[name="menu_open"]:checked');
  if(!s) return;
  const r=await sh('sh '+API+' set_menu_open '+s.value);
  const ok=r.stdout.indexOf('OK')!==-1;
  const mentag=document.getElementById('menuTag');
  if(mentag) mentag.textContent=(s.value==='bar')?'Bar':'Volume';
  toast(ok?('Menu open: '+(s.value==='bar'?'Bar':'Volume')):'Save failed', ok?'ok':'err');
}
async function saveEnabled(){
  const e=document.getElementById('enabledToggle').checked;
  await sh('sh '+API+' set_enabled '+(e?'true':'false'));
  toast(e?'Auto-start on':'Auto-start off');
}
async function fetchLogs(){
  const b=document.getElementById('logBox'); b.hidden=false; b.textContent='Loading…';
  const r=await sh('echo "--- loader ---"; tail -30 '+MOD+'/config/loader.log 2>/dev/null; '+
                   'echo; echo "--- watcher ---"; tail -20 '+MOD+'/config/watcher.log 2>/dev/null; '+
                   'echo; echo "--- kpm ---"; tail -15 '+MOD+'/config/kpm.log 2>/dev/null');
  b.textContent=r.stdout.trim()||'No logs yet.';
}
async function runDiag(){
  const b=document.getElementById('diagBox'); b.hidden=false; b.textContent='Running…';
  const r=await sh(
    'echo "module  : $( [ -d '+MOD+' ] && echo yes || echo NO )"; '+
    'echo "binary  : $(B=$(sh '+MOD+'/bin/binpath.sh); [ -n "$B" ] && basename "$B" || echo MISSING)"; '+
    'echo "watcher : $( P=$(cat '+MOD+'/config/watcher.pid 2>/dev/null); [ -n "$P" ] && kill -0 $P 2>/dev/null && echo running || echo stopped )"; '+
    'echo "loader  : $( P=$(cat '+MOD+'/config/loader.pid 2>/dev/null); [ -n "$P" ] && kill -0 $P 2>/dev/null && echo running || echo not-running )"; '+
    'echo "kernel  : $(uname -r)"; '+
    'echo "hwid    : $(cat '+MOD+'/config/.ix_hwid 2>/dev/null)"; '+
    'echo "drivers : $(ls '+MOD+'/drivers 2>/dev/null | wc -l) file(s)"; '+
    'echo "ff      : $(pidof com.dts.freefireth 2>/dev/null || pidof com.dts.freefiremax 2>/dev/null || echo not-running)"'
  );
  const ping=await binJSON('ping');
  b.textContent=r.stdout.trim()+'\nnet(bin): '+(ping.__err?'FAIL — '+ping.__err:(ping.ok?'OK':'FAIL'));
}

/* ── init ── */
(function(){
  if(!ready()){
    document.querySelector('main').insertAdjacentHTML('afterbegin',
      '<div class="card"><div class="warn"><b>Open from your root app</b>'+
      '<p>This page needs the WebUI shell bridge. Open it from KernelSU, APatch or MMRL.</p></div></div>');
    return;
  }
  refresh(); initLogin();
  setInterval(refresh,8000);
})();

/* ══════════════ DRIVER MANAGER ══════════════ */
let drvRows = [], kSeries = '';

const TYPE_LABEL = {rt:'rt-dev / rt-proc', gt:'GT', qx:'QX', kpm:'KPM',
                    kma:'KMA KPM', ldk:'LDK KPM', tb:'TB KPM', ditpro:'DitPro KPM'};










