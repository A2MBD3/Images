#!/system/bin/sh
# late_start service: ensure daemon is always running
MODDIR=${0%/*}
chmod 755 "$MODDIR/daemon.sh" "$MODDIR/bin/inx.sh" 2>/dev/null
mkdir -p /data/local/tmp/inx_logs

# wait for system
sleep 5

# kill stale lock if process dead
LOCK=/data/local/tmp/inx_daemon.lock
if [ -f "$LOCK" ]; then
  OP=$(cat "$LOCK" 2>/dev/null)
  if [ -z "$OP" ] || [ ! -d "/proc/$OP" ]; then
    rm -f "$LOCK"
  fi
fi

# start daemon in background (survives)
export MODDIR
nohup "$MODDIR/daemon.sh" >/data/local/tmp/inx_logs/daemon_boot.log 2>&1 &

# watchdog: every 30s ensure daemon lock is alive
while true; do
  sleep 30
  if [ -f "$LOCK" ]; then
    OP=$(cat "$LOCK" 2>/dev/null)
    if [ -n "$OP" ] && [ -d "/proc/$OP" ]; then
      continue
    fi
  fi
  rm -f "$LOCK"
  export MODDIR
  nohup "$MODDIR/daemon.sh" >/data/local/tmp/inx_logs/daemon_boot.log 2>&1 &
done
