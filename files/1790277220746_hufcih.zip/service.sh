#!/system/bin/sh
MODDIR=${0%/*}
CACERT_DIR=$MODDIR/system/etc/security/cacerts

# Wait for boot
i=0
while [ $i -lt 120 ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && break
    sleep 1
    i=$((i+1))
done
sleep 5

# ── CA setup ──
mkdir -p /data/misc/user/0/cacerts-added 2>/dev/null
for f in $CACERT_DIR/*.0; do
    [ -f "$f" ] || continue
    name=$(basename "$f")
    cp "$f" /data/misc/user/0/cacerts-added/"$name" 2>/dev/null
    chmod 644 /data/misc/user/0/cacerts-added/"$name" 2>/dev/null
    chown system:system /data/misc/user/0/cacerts-added/"$name" 2>/dev/null
    chcon u:object_r:misc_user_data_file:s0 /data/misc/user/0/cacerts-added/"$name" 2>/dev/null
done

APEX_DIR="/apex/com.android.conscrypt/cacerts"
BACKUP="/data/local/tmp/apex_cacerts_backup"
if [ -d "$APEX_DIR" ]; then
    if [ ! -d "$BACKUP" ] || [ ! "$(ls -A $BACKUP 2>/dev/null)" ]; then
        mkdir -p "$BACKUP"
        cp -a "$APEX_DIR"/* "$BACKUP"/ 2>/dev/null
    fi
    mount -t tmpfs tmpfs "$APEX_DIR" 2>/dev/null
    cp -a "$BACKUP"/* "$APEX_DIR"/ 2>/dev/null
    for f in $CACERT_DIR/*.0; do
        [ -f "$f" ] || continue
        name=$(basename "$f")
        cp "$f" "$APEX_DIR"/"$name" 2>/dev/null
    done
    chmod 644 "$APEX_DIR"/* 2>/dev/null
    chown root:root "$APEX_DIR"/* 2>/dev/null
    chcon u:object_r:system_file:s0 "$APEX_DIR"/* 2>/dev/null
fi

# ── Kill old ──
pkill -9 -f "/data/local/tmp/\." 2>/dev/null
sleep 2

# ✅ Cleanup ALL old .random binaries + logs + state
find /data/local/tmp -maxdepth 1 -name '.????????????????' -type f -delete 2>/dev/null
find /data/local/tmp -maxdepth 1 -name '.??????????????' -type f -delete 2>/dev/null
rm -f /data/local/tmp/akatsuki.log
rm -f /data/local/tmp/.akatsuki_rules.json

# ── Start ──
RAND_NAME=".$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')"
cp "$MODDIR/bin/akatsuki-release" "/data/local/tmp/$RAND_NAME"
chmod 700 "/data/local/tmp/$RAND_NAME"
chown root:root "/data/local/tmp/$RAND_NAME"
nohup "/data/local/tmp/$RAND_NAME" > /dev/null 2>&1 &

# ── Watchdog ──
(
while true; do
    sleep 60
    if ! netstat -tln 2>/dev/null | grep -q ":8443 "; then
        pkill -9 -f "/data/local/tmp/\." 2>/dev/null
        # Clean old before new
        find /data/local/tmp -maxdepth 1 -name '.????????????????' -type f -delete 2>/dev/null
        find /data/local/tmp -maxdepth 1 -name '.??????????????' -type f -delete 2>/dev/null
        sleep 3
        RAND_NAME=".$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')"
        cp "$MODDIR/bin/akatsuki-release" "/data/local/tmp/$RAND_NAME"
        chmod 700 "/data/local/tmp/$RAND_NAME"
        chown root:root "/data/local/tmp/$RAND_NAME"
        nohup "/data/local/tmp/$RAND_NAME" > /dev/null 2>&1 &
    fi
done
) &

exit 0
