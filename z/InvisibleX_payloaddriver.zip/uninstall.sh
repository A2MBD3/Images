#!/system/bin/sh
# stop daemon + binary
if [ -f /data/local/tmp/inx_daemon.lock ]; then
  kill "$(cat /data/local/tmp/inx_daemon.lock)" 2>/dev/null
fi
if [ -f /data/local/tmp/inx_loader.pid ]; then
  kill "$(cat /data/local/tmp/inx_loader.pid)" 2>/dev/null
fi
rm -f /data/local/tmp/inx_daemon.lock /data/local/tmp/inx_loader.pid /data/local/tmp/inx_running.flag
rm -f /data/local/tmp/.inx_license_key /data/local/tmp/.kd_saved_key
