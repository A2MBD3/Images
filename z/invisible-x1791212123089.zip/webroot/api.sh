#!/system/bin/sh
# api.sh — local helper for the WebUI (called through ksu.exec).
# NOTE: network calls are done by the WebUI in JavaScript, because many
# ROMs (including this user's) ship no curl at all. net.sh is only the
# fallback used by the daemon side.
M=/data/adb/modules/invisiblex_loader
CFG=$M/config/config.json
HWFILE=$M/config/.ix_hwid
NET=$M/webroot/net.sh
API_BASE="https://crxx.onrender.com/inx03/hwid_api.php"

mkdir -p "$M/config"
[ -f "$CFG" ] || echo '{"enabled":true,"driver":"kma","hwid_status":"unknown"}' > "$CFG"

read_hwid() {
  # Single source of truth. See bin/hwid.sh for why the old
  # android_id based value was not actually permanent.
  sh "$M/bin/hwid.sh" get
}

set_key() {
  T="$M/config/.tmp$$"
  if grep -q "\"$1\"" "$CFG" 2>/dev/null; then
    sed "s|\"$1\"[[:space:]]*:[[:space:]]*[^,}]*|\"$1\": $2|" "$CFG" > "$T" && mv "$T" "$CFG"
  else
    sed "s|^{|{\"$1\": $2, |" "$CFG" > "$T" && mv "$T" "$CFG"
  fi
}

# Which HTTP tool, if any, is usable from shell
http_tool() {
  command -v curl >/dev/null 2>&1 && { echo curl; return; }
  for BB in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox \
            /data/adb/ap/bin/busybox /system/bin/busybox /system/xbin/busybox; do
    [ -x "$BB" ] && { echo "busybox:$BB"; return; }
  done
  command -v wget >/dev/null 2>&1 && { echo wget; return; }
  [ -x /system/bin/toybox ] && { echo toybox; return; }
  echo none
}

case "$1" in
  hwid)       read_hwid ;;
  http_tool)  http_tool ;;

  # Daemon may use shell auth. WebUI License uses bin/ix_webui_auth (compiled).
  auth)
    HW=$(read_hwid)
    R=$(sh "$NET" "$API_BASE?action=status&hwid=$HW" 2>/dev/null)
    if [ -n "$R" ]; then
      ST=$(echo "$R" | grep -o '"status"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/')
      [ -n "$ST" ] && set_key hwid_status "\"$ST\""
      echo "$R"
    else
      echo '{"ok":false,"status":"no_http_tool","error":"No curl/wget/busybox on this device"}'
    fi ;;

  # WebUI calls this after doing the fetch itself, to cache the result
  save_status) [ -n "$2" ] && set_key hwid_status "\"$2\"" && echo OK ;;

  set_driver)  [ -n "$2" ] && set_key driver  "\"$2\"" && echo OK ;;

  # ── KPM driver ────────────────────────────────────────────
  get_kpm)
    P=$(grep -o '"kpm_path"[^,}]*' "$CFG" 2>/dev/null | cut -d: -f2- | tr -d ' "')
    B=$(grep -o '"kpm_boot"[^,}]*'  "$CFG" 2>/dev/null | cut -d: -f2  | tr -d ' "')
    W=$(sh "$M/bin/kpm.sh" which)
    echo "{\"path\":\"$P\",\"boot\":\"$B\",\"manager\":\"$W\"}" ;;

  set_kpm_path)
    shift; NEWP="$*"
    set_key kpm_path "\"$NEWP\"" && echo OK ;;

  set_kpm_boot) [ -n "$2" ] && set_key kpm_boot "$2" && echo OK ;;

  kpm_load)
    P=$(grep -o '"kpm_path"[^,}]*' "$CFG" 2>/dev/null | cut -d: -f2- | tr -d ' "')
    [ -n "$2" ] && P="$2"
    sh "$M/bin/kpm.sh" load "$P" ;;

  kpm_list) sh "$M/bin/kpm.sh" list ;;
  set_menu_open)
    case "$2" in
      vol|bar) set_key menu_open "\"$2\"" && echo OK ;;
      *) echo FAIL ;;
    esac ;;
  set_enabled) [ -n "$2" ] && set_key enabled "$2"     && echo OK ;;
  *) echo '{"error":"unknown command"}' ;;
esac
