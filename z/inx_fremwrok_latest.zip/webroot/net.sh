#!/system/bin/sh
# net.sh — HTTP GET that works without curl.
# Tries every tool an Android device might actually have, in order.
# Usage: net.sh <url>    -> body on stdout, exit 0 on success
U="$1"
[ -z "$U" ] && exit 1

# 1. curl, if the ROM has it
command -v curl >/dev/null 2>&1 && exec curl -sf --max-time 10 "$U"

# 2. busybox shipped by the root manager (most reliable fallback)
for BB in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox \
          /data/adb/ap/bin/busybox /data/adb/modules/busybox-ndk/system/bin/busybox \
          /system/bin/busybox /system/xbin/busybox; do
    [ -x "$BB" ] || continue
    OUT=$("$BB" wget -q -T 10 -O - "$U" 2>/dev/null) && [ -n "$OUT" ] && { echo "$OUT"; exit 0; }
done

# 3. plain wget / toybox wget
command -v wget >/dev/null 2>&1 && {
    OUT=$(wget -q -T 10 -O - "$U" 2>/dev/null) && [ -n "$OUT" ] && { echo "$OUT"; exit 0; }
}
[ -x /system/bin/toybox ] && {
    OUT=$(/system/bin/toybox wget -O - "$U" 2>/dev/null) && [ -n "$OUT" ] && { echo "$OUT"; exit 0; }
}

exit 1
