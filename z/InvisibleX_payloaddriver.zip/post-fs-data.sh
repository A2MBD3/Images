#!/system/bin/sh
MODDIR=${0%/*}
mkdir -p "$MODDIR/config" /data/local/tmp/inx_logs
chmod 755 "$MODDIR/bin/inx.sh" "$MODDIR/daemon.sh" "$MODDIR/webroot/api.sh" 2>/dev/null
# early flag so service knows module is active
touch /data/local/tmp/inx_module_ready
