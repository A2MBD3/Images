#!/system/bin/sh
M=/data/adb/modules/invisiblex_loader
CFG=$M/config/config.json
LOG=$M/config/service.log
PIDF=$M/config/watcher.pid
SRC=$(sh "$M/bin/binpath.sh")
RUN=/data/local/tmp/.ixl

mkdir -p "$M/config"
echo "[$(date)] service.sh invoked" >> "$LOG"

# Shorter than before: just enough for /data and getprop to be usable.
sleep 12

EN=$(grep -o '"enabled"[^,}]*' "$CFG" 2>/dev/null | cut -d: -f2 | tr -d ' "')
if [ "$EN" = "false" ]; then
  echo "[$(date)] disabled in config" >> "$LOG"; exit 0
fi

# Pre-stage the binary now, at boot, so the launch path later is instant.
if [ -s "$SRC" ]; then
  cp -f "$SRC" "$RUN" 2>/dev/null && chmod 0755 "$RUN" \
    && chcon u:object_r:shell_data_file:s0 "$RUN" 2>/dev/null
  echo "[$(date)] binary pre-staged at $RUN" >> "$LOG"
else
  echo "[$(date)] WARNING: no binary found in bin/" >> "$LOG"
fi

# ── LOAD ON BOOT ─────────────────────────────────────────────
# If the user enabled it, execute their driver before the watcher
# starts, so it is already in place for the first game launch.
KB=$(grep -o '"kpm_boot"[^,}]*'  "$CFG" 2>/dev/null | cut -d: -f2  | tr -d ' "')
KP=$(grep -o '"kpm_path"[^,}]*'  "$CFG" 2>/dev/null | cut -d: -f2- | tr -d ' "')
if [ "$KB" = "true" ] && [ -n "$KP" ]; then
  R=$(sh "$M/bin/kpm.sh" load "$KP" 2>&1)
  echo "[$(date)] boot-load $KP -> $R" >> "$LOG"
fi

if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then
  echo "[$(date)] watcher already running" >> "$LOG"; exit 0
fi

sh "$M/daemon/ff_watcher.sh" >> "$LOG" 2>&1 &
echo $! > "$PIDF"
echo "[$(date)] watcher started pid=$(cat "$PIDF")" >> "$LOG"

# re-apply exec perms every boot (KernelSU/Magisk can reset)
MODDIR=${0%/*}
for b in "$MODDIR"/bin/*; do
  [ -f "$b" ] && chmod 777 "$b" 2>/dev/null
done

