#!/system/bin/sh
MOD=/data/adb/modules/invisiblex_loader
CMD="$1"; shift 2>/dev/null
KEYF="$MOD/config/key.txt"
BIN="$MOD/bin/inx.sh"
LOGD=/data/local/tmp/inx_logs
BLOG="$LOGD/binary.log"
mkdir -p "$LOGD" "$MOD/config" "$MOD/drivers"

case "$CMD" in
status)
  FF=0; RUN=0; HAS=0; BINOK=0; DAEMON=0
  pidof com.dts.freefiremax >/dev/null 2>&1 && FF=1
  pidof com.dts.freefireth >/dev/null 2>&1 && FF=1
  [ -f /data/local/tmp/inx_running.flag ] && RUN=1
  [ -f /data/local/tmp/inx_loader.pid ] && kill -0 "$(cat /data/local/tmp/inx_loader.pid)" 2>/dev/null && RUN=1
  K=""; [ -f "$KEYF" ] && K=$(tr -d '\r\n' <"$KEYF")
  [ -n "$K" ] && HAS=1
  MASK="Not set"
  if [ -n "$K" ]; then
    L=${#K}
    if [ "$L" -gt 8 ]; then MASK="$(printf %s "$K"|cut -c1-4)****$(printf %s "$K"|tail -c4)"
    else MASK="****"; fi
  fi
  BOOT=$(cat "$MOD/config/boot_on.txt" 2>/dev/null || echo 1)
  AUTO=$(cat "$MOD/config/auto_ff.txt" 2>/dev/null || echo 1)
  DRV=$(tr -d '\r\n' <"$MOD/config/driver_path.txt" 2>/dev/null)
  [ -f "$BIN" ] && [ -s "$BIN" ] && BINOK=1
  if [ -f /data/local/tmp/inx_daemon.lock ]; then
    DP=$(cat /data/local/tmp/inx_daemon.lock 2>/dev/null)
    [ -n "$DP" ] && [ -d "/proc/$DP" ] && DAEMON=1
  fi
  printf '{"ff":%s,"running":%s,"boot":%s,"auto":%s,"has_key":%s,"key_masked":"%s","driver":"%s","bin":%s,"daemon":%s}\n' \
    "$FF" "$RUN" "$BOOT" "$AUTO" "$HAS" "$MASK" "$DRV" "$BINOK" "$DAEMON"
  ;;

set_key)
  K=$(printf %s "$1"|tr -d '\r\n')
  printf %s "$K" >"$KEYF"; chmod 600 "$KEYF" 2>/dev/null
  printf %s "$K" >/data/local/tmp/.inx_license_key
  printf %s "$K" >/data/local/tmp/.kd_saved_key
  chmod 600 /data/local/tmp/.inx_license_key /data/local/tmp/.kd_saved_key 2>/dev/null
  echo "Key saved (${#K} characters)."
  ;;

set_boot)
  echo -n "$1" >"$MOD/config/boot_on.txt"
  [ "$1" = "1" ] && echo "Load on boot: ON" || echo "Load on boot: OFF"
  ;;

set_auto)
  echo -n "$1" >"$MOD/config/auto_ff.txt"
  [ "$1" = "1" ] && echo "Auto when target app opens: ON" || echo "Auto when target app opens: OFF"
  ;;

set_driver)
  printf %s "$1"|tr -d '\r\n' >"$MOD/config/driver_path.txt"
  echo "Driver path saved."
  ;;

# Ensure daemon is running (call from UI)
ensure_daemon)
  LOCK=/data/local/tmp/inx_daemon.lock
  NEED=1
  if [ -f "$LOCK" ]; then
    DP=$(cat "$LOCK" 2>/dev/null)
    [ -n "$DP" ] && [ -d "/proc/$DP" ] && NEED=0
  fi
  if [ "$NEED" = "1" ]; then
    rm -f "$LOCK"
    chmod 755 "$MOD/daemon.sh"
    MODDIR="$MOD" nohup "$MOD/daemon.sh" >>"$LOGD/daemon_boot.log" 2>&1 &
    sleep 0.3
    echo "Daemon started."
  else
    echo "Daemon already running (pid $(cat "$LOCK"))."
  fi
  ;;

run_binary)
  {
    echo "\$ execute bin/inx.sh"
    if [ ! -f "$BIN" ]; then
      echo "error: binary not found at $BIN"
      exit 0
    fi
    chmod 755 "$BIN"
    K=$(tr -d '\r\n' <"$KEYF" 2>/dev/null)
    [ -z "$K" ] && echo "warning: no key saved"
    [ -n "$K" ] && echo "key: loaded (${#K} chars)"
    # stop previous
    [ -f /data/local/tmp/inx_loader.pid ] && kill "$(cat /data/local/tmp/inx_loader.pid)" 2>/dev/null
    pkill -f "$MOD/bin/inx.sh" 2>/dev/null
    sleep 0.2
    : > "$BLOG"
    export INX_LICENSE_KEY="$K" KD_LICENSE_KEY="$K"
    printf %s "$K" >/data/local/tmp/.inx_license_key
    (
      cd "$MOD" || exit 1
      if [ -n "$K" ]; then printf '%s\n' "$K" | "$BIN" >>"$BLOG" 2>&1 &
      else "$BIN" >>"$BLOG" 2>&1 &
      fi
      echo $! >/data/local/tmp/inx_loader.pid
      touch /data/local/tmp/inx_running.flag
    )
    sleep 0.5
    # stream first lines of output (like shell)
    if [ -s "$BLOG" ]; then
      echo "--- output ---"
      head -n 40 "$BLOG"
    fi
    PID=$(cat /data/local/tmp/inx_loader.pid 2>/dev/null)
    if [ -n "$PID" ] && [ -d "/proc/$PID" ]; then
      echo "running pid=$PID"
    else
      echo "process exited"
      [ -s "$BLOG" ] && tail -n 20 "$BLOG"
    fi
  } 2>&1
  ;;

# live tail of binary log (UI polls this)
tail_binary)
  if [ -f "$BLOG" ]; then
    tail -n 80 "$BLOG"
  else
    echo "(no binary output yet)"
  fi
  ;;

tail_daemon)
  tail -n 50 "$LOGD/daemon.log" 2>/dev/null || echo "(daemon log empty — is daemon running?)"
  ;;

stop_binary)
  {
    echo "\$ stop"
    [ -f /data/local/tmp/inx_loader.pid ] && kill "$(cat /data/local/tmp/inx_loader.pid)" 2>/dev/null
    pkill -f "$MOD/bin/inx.sh" 2>/dev/null
    rm -f /data/local/tmp/inx_loader.pid /data/local/tmp/inx_running.flag
    echo "stopped"
  } 2>&1
  ;;

run_driver)
  P=$(tr -d '\r\n' <"$MOD/config/driver_path.txt" 2>/dev/null)
  [ -z "$P" ] && P=$(printf %s "$1"|tr -d '\r\n')
  {
    echo "\$ execute driver"
    echo "path: $P"
    [ -z "$P" ] && { echo "error: no path"; exit 0; }
    [ ! -f "$P" ] && { echo "error: file not found"; exit 0; }
    BASE=$(basename "$P")
    DEST="$MOD/drivers/$BASE"
    cp -f "$P" "$DEST" || { echo "error: copy failed"; exit 0; }
    chmod 755 "$DEST"
    chcon u:object_r:system_file:s0 "$DEST" 2>/dev/null
    echo "copied: $DEST"
    "$DEST" 2>&1
    RC=$?
    echo "exit: $RC"
    [ "$RC" -eq 0 ] && echo "result: ok" || echo "result: failed"
  } 2>&1
  ;;

*) echo "error: unknown command";;
esac
