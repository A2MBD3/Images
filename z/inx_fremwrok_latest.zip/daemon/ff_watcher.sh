#!/system/bin/sh
# ff_watcher.sh — instant launch / instant exit
M=/data/adb/modules/invisiblex_loader
CFG=$M/config/config.json
LOADER=$M/bin/loader.sh
LOG=$M/config/watcher.log
STAGED=/data/local/tmp/.ixl
PKG1=com.dts.freefireth
PKG2=com.dts.freefiremax

log(){ echo "[$(date '+%H:%M:%S')] $1" >> "$LOG"; }

# ── poll interval ────────────────────────────────────────────
# Sub-second polling is what makes launch feel instant. Not every
# ROM's sleep accepts decimals, so probe once and fall back.
if sleep 0.25 2>/dev/null; then TICK="0.25"; else TICK="1"; fi
log "watcher started (pid $$, tick ${TICK}s)"

# ── pre-stage the binary ─────────────────────────────────────
# Copying 3-4 MB at launch time cost a visible delay. Do it now,
# while nothing is waiting on it.
stage(){
  SRC=$(sh "$M/bin/binpath.sh")
  [ -n "$SRC" ] && [ -s "$SRC" ] || return 1
  if [ ! -s "$STAGED" ] || [ "$(stat -c%s "$SRC" 2>/dev/null)" != "$(stat -c%s "$STAGED" 2>/dev/null)" ]; then
    cp -f "$SRC" "$STAGED" 2>/dev/null || return 1
    chmod 0755 "$STAGED"
    chcon u:object_r:shell_data_file:s0 "$STAGED" 2>/dev/null
    log "binary staged to $STAGED"
  fi
  return 0
}
stage || log "WARNING: no binary found in bin/ — nothing to launch"

# ── fast pid lookup ──────────────────────────────────────────
# pidof is a C-level /proc scan and is cheap enough to run 4x a
# second. The shell /proc walk is only a last resort, so it is not
# in the hot path.
find_pid(){
  X=$(pidof "$PKG1" 2>/dev/null); [ -n "$X" ] && { echo "${X%% *}"; return; }
  X=$(pidof "$PKG2" 2>/dev/null); [ -n "$X" ] && { echo "${X%% *}"; return; }
}
find_pid_deep(){
  for P in "$PKG1" "$PKG2"; do
    X=$(pgrep -f "^$P$" 2>/dev/null | head -1); [ -n "$X" ] && { echo "$X"; return; }
    for D in /proc/[0-9]*; do
      [ -r "$D/cmdline" ] || continue
      case "$(tr -d '\0' < "$D/cmdline" 2>/dev/null)" in "$P"*) echo "${D#/proc/}"; return;; esac
    done
  done
}

LAST=0
DEEP=0

while true; do
  sleep "$TICK"

  GP=$(find_pid)
  # Only fall back to the expensive scan every ~5s, and only while
  # nothing is running, so the fast path stays fast.
  if [ -z "$GP" ]; then
    DEEP=$((DEEP+1))
    if [ "$DEEP" -ge 20 ]; then DEEP=0; GP=$(find_pid_deep); fi
  fi

  if [ -z "$GP" ]; then LAST=0; continue; fi
  [ "$GP" = "$LAST" ] && continue

  LAST=$GP
  DRV=$(grep -o '"driver"[^,}]*' "$CFG" 2>/dev/null | cut -d: -f2 | tr -d ' "')
  [ -z "$DRV" ] && DRV=kma
  log "game up pid=$GP driver=$DRV — launching now"

  stage
  # No delay: the loader re-resolves the game itself, so there is
  # nothing to wait for. This is what makes it feel instant.
  sh "$LOADER" "$DRV" "$GP" >> "$LOG" 2>&1

  # ── watch for exit at the same fast tick ───────────────────
  while :; do
    sleep "$TICK"
    kill -0 "$GP" 2>/dev/null && continue
    # pid vanished — the game may have re-spawned its process
    NG=$(find_pid)
    if [ -n "$NG" ] && [ "$NG" != "$GP" ]; then
      log "pid $GP -> $NG (game respawned)"
      GP=$NG; LAST=$NG; continue
    fi
    [ -n "$NG" ] && continue
    break
  done

  log "game closed — stopping loader"
  LP=$(cat "$M/config/loader.pid" 2>/dev/null)
  if [ -n "$LP" ]; then
    kill "$LP" 2>/dev/null
    sleep "$TICK"
    kill -9 "$LP" 2>/dev/null
    pkill -9 -f "$STAGED" 2>/dev/null
  fi
  rm -f "$M/config/loader.pid"
  LAST=0
done
