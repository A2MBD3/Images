#!/system/bin/sh
MODDIR=${0%/*}
CACERT_DIR=$MODDIR/system/etc/security/cacerts

# Install to system store early
for f in $CACERT_DIR/*.0; do
    [ -f "$f" ] || continue
    name=$(basename "$f")
    cp "$f" /system/etc/security/cacerts/"$name" 2>/dev/null
    chmod 644 /system/etc/security/cacerts/"$name" 2>/dev/null
    chown root:root /system/etc/security/cacerts/"$name" 2>/dev/null
    chcon u:object_r:system_file:s0 /system/etc/security/cacerts/"$name" 2>/dev/null
done
exit 0
