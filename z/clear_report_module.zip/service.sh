#!/system/bin/sh
#Don't Copy paste my modules @NOERA_OFC

LOGFILE=/storage/emulated/0/selog.txt

# 🛡️ Enforce SELinux continuously
(
while true; do
  if [ "$(getenforce)" = "Permissive" ]; then
    echo "$(date): SELinux set to Enforcing" >> "$LOGFILE"
    setenforce 1
  fi
  sleep 2
done
) &

# 🧹 Clean cache and logs loop
(
CLEAN_PATHS="
/storage/emulated/0/Android/data/com.dts.freefireth/cache
/storage/emulated/0/Android/data/com.dts.freefireth/files/cache
/storage/emulated/0/Android/data/com.dts.freefireth/Cache
/storage/emulated/0/Android/data/com.dts.freefiremax/cache
/data/user/0/com.dts.freefireth/cache
/data/user/0/com.dts.freefiremax/cache
/data/user/0/com.dts.freefireth/databases
/data/user/0/com.dts.freefiremax/databases
/data/user/0/com.dts.freefireth/files/AFRequestCache
/data/user/0/com.dts.freefiremax/files/AFRequestCache
/data/user/0/com.dts.freefireth/files/.com.google.firebase.crashlytics.files.v2_com.dts.freefireth
/data/user/0/com.dts.freefireth/files/datastore
/data/user/0/com.dts.freefiremax/files/datastore
/storage/emulated/0/Android/data/com.dts.freefireth/files/ffrtc_log.txt
/storage/emulated/0/Android/data/com.dts.freefireth/files/ffrtc_log.txt.bak
/storage/emulated/0/Android/data/com.dts.freefireth/files/ffrtc_log_bak.txt
/storage/emulated/0/Android/data/com.dts.freefireth/files/reportnew.db
/storage/emulated/0/Android/data/com.dts.freefiremax/files/reportnew.db
/data/user/0/com.dts.freefireth/files/.com.google.firebase.crashlytics.files.v2:com.dts.freefireth
/data/user/0/com.dts.freefiremax/files/.com.google.firebase.crashlytics.files.v2:com.dts.freefiremax
/storage/emulated/0/Android/data/com.dts.freefiremax/files/ffrtc_log.txt
"

while true; do
  for path in $CLEAN_PATHS; do
    if [ -e "$path" ]; then
      rm -rf "$path"
    fi
  done
  sleep 5
done
) &
